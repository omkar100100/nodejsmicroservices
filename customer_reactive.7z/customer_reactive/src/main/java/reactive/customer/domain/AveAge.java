package reactive.customer.domain;

public class AveAge {
	
	private Double average;

	public Double getAverage() {
		return average;
	}

	public void setAverage(Double average) {
		this.average = average;
	}
	
	

}
